/* =========================================================
   PORTFOLIO SCRIPT — Mohammed Aafrin Salam
   Keep data arrays at the top — edit these to update content
   without touching any HTML.
   ========================================================= */

/* ---------- EDITABLE DATA ---------- */

// Add / remove / edit skills here. `icon` is any Font Awesome class.
const SKILLS = [
  { name: "HTML", icon: "fa-brands fa-html5", level: 4 },
  { name: "CSS", icon: "fa-brands fa-css3-alt", level: 3 },
  { name: "JavaScript", icon: "fa-brands fa-js", level: 3 },
  { name: "Python", icon: "fa-brands fa-python", level: 3 },
  { name: "Java", icon: "fa-solid fa-mug-hot", level: 2 },
  { name: "SQL", icon: "fa-solid fa-database", level: 2 },
  { name: "Git", icon: "fa-brands fa-git-alt", level: 3 },
  { name: "GitHub", icon: "fa-brands fa-github", level: 3 },
  { name: "Django", icon: "fa-solid fa-server", level: 2 },
  { name: "SQLite", icon: "fa-solid fa-database", level: 2 },
  { name: "React (basics)", icon: "fa-brands fa-react", level: 2 },
  { name: "APIs", icon: "fa-solid fa-plug", level: 2 },
  { name: "LLM / AI concepts", icon: "fa-solid fa-brain", level: 2 },
  { name: "n8n (basics)", icon: "fa-solid fa-diagram-project", level: 1 },
];

// Add new projects here — this is the "Add Project" structure.
// links.github / links.demo default to "#" placeholders until you add real URLs.
const PROJECTS = [
  {
    name: "Smart Mobility",
    tag: "Hackathon Concept",
    icon: "fa-solid fa-route",
    description:
      "A hackathon/project concept exploring smart mobility solutions — using modern web technologies alongside AI-related ideas to rethink everyday transport problems.",
    tech: ["HTML", "CSS", "JavaScript", "AI Concepts"],
    links: { github: "#", demo: "#" },
  },
  {
    name: "SkillSwap",
    tag: "Web Platform",
    icon: "fa-solid fa-handshake",
    description:
      "A college-focused, hyper-local skill-sharing platform where students can discover, offer, and exchange skills with other students nearby.",
    tech: ["HTML", "CSS", "JavaScript", "Django", "SQLite"],
    links: { github: "#", demo: "#" },
  },
  // 👉 To add a new project, copy the block below and fill it in:
  // {
  //   name: "Project Name",
  //   tag: "Category",
  //   icon: "fa-solid fa-code",
  //   description: "Short description of the project.",
  //   tech: ["Tech1", "Tech2"],
  //   links: { github: "https://github.com/...", demo: "https://..." },
  // },
];

// Certification placeholders — replace values with real data when earned.
const CERTIFICATIONS = [
  { name: "[Certification Name]", org: "[Issuing Organization]", date: "[Date]", link: "#" },
  { name: "[Certification Name]", org: "[Issuing Organization]", date: "[Date]", link: "#" },
  { name: "[Certification Name]", org: "[Issuing Organization]", date: "[Date]", link: "#" },
];

const ROLE_WORDS = ["CSBS Student.", "Aspiring Web Developer.", "AI/ML Learner.", "Hackathon Enthusiast."];

/* ---------- RENDER: SKILLS ---------- */
function renderSkills() {
  const grid = document.getElementById("skillsGrid");
  grid.innerHTML = SKILLS.map((s) => `
    <div class="skill-card reveal">
      <i class="${s.icon}"></i>
      <h4>${s.name}</h4>
      <div class="skill-level">
        ${[1, 2, 3, 4].map((n) => `<span class="${n <= s.level ? "filled" : ""}"></span>`).join("")}
      </div>
    </div>
  `).join("");
}

/* ---------- RENDER: PROJECTS ---------- */
function renderProjects() {
  const grid = document.getElementById("projectsGrid");
  grid.innerHTML = PROJECTS.map((p) => {
    const hasGithub = p.links.github && p.links.github !== "#";
    const hasDemo = p.links.demo && p.links.demo !== "#";
    return `
      <div class="project-card reveal">
        <div class="project-card-top">
          <div class="project-icon"><i class="${p.icon}"></i></div>
          <span class="project-tag-mini">${p.tag}</span>
        </div>
        <h3>${p.name}</h3>
        <p>${p.description}</p>
        <div class="project-tech">
          ${p.tech.map((t) => `<span>${t}</span>`).join("")}
        </div>
        <div class="project-links">
          <a href="${p.links.github}" target="_blank" rel="noopener" class="${hasGithub ? "" : "disabled"}" title="${hasGithub ? "View on GitHub" : "GitHub link coming soon"}">
            <i class="fa-brands fa-github"></i> Code
          </a>
          <a href="${p.links.demo}" target="_blank" rel="noopener" class="${hasDemo ? "" : "disabled"}" title="${hasDemo ? "View live demo" : "Live demo coming soon"}">
            <i class="fa-solid fa-arrow-up-right-from-square"></i> Demo
          </a>
        </div>
      </div>
    `;
  }).join("");
}

/* ---------- RENDER: CERTIFICATIONS ---------- */
function renderCertifications() {
  const grid = document.getElementById("certGrid");
  grid.innerHTML = CERTIFICATIONS.map((c) => `
    <div class="cert-card reveal">
      <i class="fa-solid fa-certificate"></i>
      <h4>${c.name}</h4>
      <div class="cert-field">Issued by: ${c.org}</div>
      <div class="cert-field">Date: ${c.date}</div>
      <div class="cert-field">Credential: <a href="${c.link}" style="color:var(--accent)">Add link</a></div>
    </div>
  `).join("");
}

/* ---------- ADD PROJECT (simple prompt-based helper) ---------- */
function setupAddProject() {
  const btn = document.getElementById("addProjectBtn");
  btn.addEventListener("click", () => {
    const name = prompt("Project name?");
    if (!name) return;
    const description = prompt("Short description?") || "";
    const techInput = prompt("Technologies used (comma separated)?") || "";
    PROJECTS.push({
      name,
      tag: "New",
      icon: "fa-solid fa-code",
      description,
      tech: techInput.split(",").map((t) => t.trim()).filter(Boolean),
      links: { github: "#", demo: "#" },
    });
    renderProjects();
    document.getElementById("projects").scrollIntoView({ behavior: "smooth" });
  });
}

/* ---------- THEME TOGGLE ---------- */
function setupTheme() {
  const toggle = document.getElementById("themeToggle");
  const icon = document.getElementById("themeIcon");
  const root = document.documentElement;

  let saved;
  try { saved = localStorage.getItem("portfolio-theme"); } catch (e) { saved = null; }

  if (saved === "light") {
    root.setAttribute("data-theme", "light");
    icon.className = "fa-solid fa-sun";
  }

  toggle.addEventListener("click", () => {
    const isLight = root.getAttribute("data-theme") === "light";
    if (isLight) {
      root.removeAttribute("data-theme");
      icon.className = "fa-solid fa-moon";
      try { localStorage.setItem("portfolio-theme", "dark"); } catch (e) {}
    } else {
      root.setAttribute("data-theme", "light");
      icon.className = "fa-solid fa-sun";
      try { localStorage.setItem("portfolio-theme", "light"); } catch (e) {}
    }
  });
}

/* ---------- MOBILE MENU ---------- */
function setupMobileMenu() {
  const hamburger = document.getElementById("hamburger");
  const menu = document.getElementById("mobileMenu");

  hamburger.addEventListener("click", () => {
    hamburger.classList.toggle("open");
    menu.classList.toggle("open");
  });

  menu.querySelectorAll(".mobile-link").forEach((link) => {
    link.addEventListener("click", () => {
      hamburger.classList.remove("open");
      menu.classList.remove("open");
    });
  });
}

/* ---------- SCROLL: PROGRESS BAR, NAVBAR STATE, BACK-TO-TOP, SCROLL-SPY ---------- */
function setupScrollEffects() {
  const progress = document.getElementById("scrollProgress");
  const navbar = document.getElementById("navbar");
  const backToTop = document.getElementById("backToTop");
  const navLinks = document.querySelectorAll(".nav-link");
  const sections = document.querySelectorAll("main section[id]");

  function onScroll() {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    progress.style.width = `${(scrollTop / docHeight) * 100}%`;

    navbar.classList.toggle("scrolled", scrollTop > 20);
    backToTop.classList.toggle("show", scrollTop > 500);

    let current = "";
    sections.forEach((section) => {
      const top = section.offsetTop - 120;
      if (scrollTop >= top) current = section.getAttribute("id");
    });
    navLinks.forEach((link) => {
      link.classList.toggle("active-link", link.getAttribute("href") === `#${current}`);
    });
  }

  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  backToTop.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

/* ---------- REVEAL ON SCROLL ---------- */
function setupReveal() {
  const targets = document.querySelectorAll(".reveal, .section-head, .timeline-item, .internship-card, .resume-box, .contact-card, .interest-card");
  targets.forEach((el) => el.classList.add("reveal"));

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
}

/* ---------- HERO TYPED ROLE TEXT ---------- */
function setupTypedRole() {
  const el = document.getElementById("typedRole");
  let wordIndex = 0;
  let charIndex = 0;
  let deleting = false;

  function tick() {
    const word = ROLE_WORDS[wordIndex];

    if (!deleting) {
      charIndex++;
      el.textContent = word.slice(0, charIndex);
      if (charIndex === word.length) {
        deleting = true;
        setTimeout(tick, 1400);
        return;
      }
    } else {
      charIndex--;
      el.textContent = word.slice(0, charIndex);
      if (charIndex === 0) {
        deleting = false;
        wordIndex = (wordIndex + 1) % ROLE_WORDS.length;
      }
    }
    setTimeout(tick, deleting ? 40 : 70);
  }
  tick();
}

/* ---------- INIT ---------- */
document.addEventListener("DOMContentLoaded", () => {
  renderSkills();
  renderProjects();
  renderCertifications();
  setupAddProject();
  setupTheme();
  setupMobileMenu();
  setupScrollEffects();
  setupReveal();
  setupTypedRole();
  document.getElementById("year").textContent = new Date().getFullYear();
});
